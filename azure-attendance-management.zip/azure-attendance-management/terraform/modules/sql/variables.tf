variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "name_prefix" { type = string }
variable "suffix" { type = string }
variable "admin_username" { type = string }
variable "admin_password" {
  type      = string
  sensitive = true
}
variable "database_sku" {
  type    = string
  default = "Basic"
}
variable "allowed_client_ip" {
  type    = string
  default = ""
}
variable "tags" {
  type    = map(string)
  default = {}
}
