variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "key_vault_name" { type = string }
variable "sql_connection_string" {
  type      = string
  sensitive = true
}
variable "app_service_principal_id" {
  description = "Managed Identity principal_id of the App Service, granted get/list on secrets"
  type        = string
}
variable "tags" {
  type    = map(string)
  default = {}
}
