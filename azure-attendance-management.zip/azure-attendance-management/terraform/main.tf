resource "random_string" "suffix" {
  length  = 5
  special = false
  upper   = false
}

locals {
  name_prefix = "${var.project_name}-${var.environment}"
  suffix      = random_string.suffix.result
  tags        = var.tags

  # Computed up-front (not read as a module output) so both the app-service
  # and keyvault modules can reference the same Key Vault name without
  # creating a circular module dependency:
  #   app-service -> needs KV name for its Key Vault reference app setting
  #   keyvault    -> needs app-service's Managed Identity principal_id
  key_vault_name = substr("kv-${var.project_name}${var.environment}${local.suffix}", 0, 24)
}

resource "azurerm_resource_group" "this" {
  name     = "rg-${local.name_prefix}"
  location = var.location
  tags     = local.tags
}

module "monitoring" {
  source = "./modules/monitoring"

  resource_group_name = azurerm_resource_group.this.name
  location             = azurerm_resource_group.this.location
  name_prefix          = local.name_prefix
  suffix               = local.suffix
  alert_email          = var.alert_email
  tags                 = local.tags
}

module "sql" {
  source = "./modules/sql"

  resource_group_name = azurerm_resource_group.this.name
  location             = azurerm_resource_group.this.location
  name_prefix          = local.name_prefix
  suffix               = local.suffix
  admin_username       = var.sql_admin_username
  admin_password       = var.sql_admin_password
  database_sku         = var.sql_database_sku
  allowed_client_ip    = var.allowed_client_ip
  tags                 = local.tags
}

# 1) App Service is created first. Its Managed Identity principal_id is a
#    computed attribute available right after resource creation - no need
#    for the Key Vault to exist yet, we only pass the *name* we already know.
module "app_service" {
  source = "./modules/app-service"

  resource_group_name              = azurerm_resource_group.this.name
  location                          = azurerm_resource_group.this.location
  name_prefix                       = local.name_prefix
  suffix                            = local.suffix
  sku_name                          = var.app_service_sku
  app_insights_connection_string    = module.monitoring.app_insights_connection_string
  app_insights_instrumentation_key  = module.monitoring.app_insights_instrumentation_key
  key_vault_name                    = local.key_vault_name
  tags                              = local.tags
}

# 2) Key Vault is created second, granting access to the App Service's
#    Managed Identity (principal_id) and storing the SQL connection string.
module "keyvault" {
  source = "./modules/keyvault"

  resource_group_name       = azurerm_resource_group.this.name
  location                   = azurerm_resource_group.this.location
  key_vault_name             = local.key_vault_name
  sql_connection_string      = module.sql.sql_connection_string
  app_service_principal_id   = module.app_service.principal_id
  tags                       = local.tags
}

# 3) Alert rule: HTTP Server Errors (5xx) > 5 within a 5-minute window,
#    evaluated every 5 minutes, notifying the monitoring module's action group.
resource "azurerm_monitor_metric_alert" "http_5xx" {
  name                = "alert-http5xx-${local.name_prefix}-${local.suffix}"
  resource_group_name = azurerm_resource_group.this.name
  scopes               = [module.app_service.app_service_id]
  description           = "Fires when HTTP 5xx responses exceed 5 in a 5 minute window"
  severity              = 2
  frequency             = "PT5M"
  window_size           = "PT5M"

  criteria {
    metric_namespace = "Microsoft.Web/sites"
    metric_name       = "Http5xx"
    aggregation        = "Total"
    operator            = "GreaterThan"
    threshold           = 5
  }

  action {
    action_group_id = module.monitoring.action_group_id
  }

  tags = local.tags
}
