require('dotenv').config();

// Must be initialized before other imports for auto-collection to work.
if (process.env.APPLICATIONINSIGHTS_CONNECTION_STRING) {
  const appInsights = require('applicationinsights');
  appInsights.setup().setSendLiveMetrics(true).start();
}

const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const { sql, getPool } = require('./db');

const app = express();
const PORT = process.env.PORT || 8080;

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'change-me-in-production',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 8 * 60 * 60 * 1000 },
  })
);

// ---- Health check (used by App Service / Front Door health probes) ----
app.get('/healthz', (req, res) => res.status(200).send('OK'));

// ---- Auth middleware ----
function requireLogin(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}
function requireManager(req, res, next) {
  if (!req.session.user || !req.session.user.isManager) return res.status(403).send('Forbidden: managers only');
  next();
}

// ---- Login ----
app.get('/login', (req, res) => res.render('login', { error: null }));

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const pool = await getPool();
    const result = await pool
      .request()
      .input('email', sql.NVarChar, email)
      .query('SELECT * FROM dbo.Employees WHERE Email = @email');

    const employee = result.recordset[0];
    if (!employee || !(await bcrypt.compare(password, employee.PasswordHash))) {
      return res.render('login', { error: 'Invalid email or password' });
    }

    req.session.user = {
      id: employee.EmployeeId,
      name: employee.Name,
      isManager: !!employee.IsManager,
    };
    res.redirect('/dashboard');
  } catch (err) {
    console.error(err);
    res.status(500).render('login', { error: 'Service temporarily unavailable. Please try again.' });
  }
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

// ---- Dashboard ----
app.get('/dashboard', requireLogin, async (req, res) => {
  const pool = await getPool();
  const today = new Date().toISOString().slice(0, 10);

  const attendanceToday = await pool
    .request()
    .input('empId', sql.Int, req.session.user.id)
    .input('today', sql.Date, today)
    .query('SELECT * FROM dbo.Attendance WHERE EmployeeId = @empId AND [Date] = @today');

  const balance = await pool
    .request()
    .input('empId', sql.Int, req.session.user.id)
    .query('SELECT LeaveBalance FROM dbo.Employees WHERE EmployeeId = @empId');

  res.render('dashboard', {
    user: req.session.user,
    todayRecord: attendanceToday.recordset[0] || null,
    leaveBalance: balance.recordset[0]?.LeaveBalance ?? 0,
  });
});

// ---- Attendance: check-in / check-out ----
app.post('/attendance/checkin', requireLogin, async (req, res) => {
  const pool = await getPool();
  const today = new Date().toISOString().slice(0, 10);
  await pool
    .request()
    .input('empId', sql.Int, req.session.user.id)
    .input('today', sql.Date, today)
    .query(`
      MERGE dbo.Attendance AS target
      USING (SELECT @empId AS EmployeeId, @today AS [Date]) AS src
      ON target.EmployeeId = src.EmployeeId AND target.[Date] = src.[Date]
      WHEN MATCHED THEN UPDATE SET CheckIn = SYSUTCDATETIME()
      WHEN NOT MATCHED THEN INSERT (EmployeeId, [Date], CheckIn, Status)
        VALUES (@empId, @today, SYSUTCDATETIME(), 'Present');
    `);
  res.redirect('/dashboard');
});

app.post('/attendance/checkout', requireLogin, async (req, res) => {
  const pool = await getPool();
  const today = new Date().toISOString().slice(0, 10);
  await pool
    .request()
    .input('empId', sql.Int, req.session.user.id)
    .input('today', sql.Date, today)
    .query('UPDATE dbo.Attendance SET CheckOut = SYSUTCDATETIME() WHERE EmployeeId = @empId AND [Date] = @today');
  res.redirect('/dashboard');
});

app.get('/attendance/history', requireLogin, async (req, res) => {
  const pool = await getPool();
  const result = await pool
    .request()
    .input('empId', sql.Int, req.session.user.id)
    .query('SELECT * FROM dbo.Attendance WHERE EmployeeId = @empId ORDER BY [Date] DESC');
  res.render('history', { user: req.session.user, records: result.recordset });
});

// ---- Leave ----
app.get('/leave', requireLogin, async (req, res) => {
  const pool = await getPool();
  const result = await pool
    .request()
    .input('empId', sql.Int, req.session.user.id)
    .query('SELECT * FROM dbo.LeaveRequests WHERE EmployeeId = @empId ORDER BY CreatedAt DESC');
  res.render('leave', { user: req.session.user, requests: result.recordset, error: null });
});

app.post('/leave/apply', requireLogin, async (req, res) => {
  const { leaveType, startDate, endDate, reason } = req.body;
  try {
    const pool = await getPool();
    await pool
      .request()
      .input('empId', sql.Int, req.session.user.id)
      .input('leaveType', sql.NVarChar, leaveType)
      .input('startDate', sql.Date, startDate)
      .input('endDate', sql.Date, endDate)
      .input('reason', sql.NVarChar, reason)
      .query(`
        INSERT INTO dbo.LeaveRequests (EmployeeId, LeaveType, StartDate, EndDate, Reason, Status)
        VALUES (@empId, @leaveType, @startDate, @endDate, @reason, 'Pending')
      `);
    res.redirect('/leave');
  } catch (err) {
    console.error(err);
    res.status(400).render('leave', { user: req.session.user, requests: [], error: 'Could not submit leave request' });
  }
});

// ---- Manager approvals ----
app.get('/manager/leave-requests', requireLogin, requireManager, async (req, res) => {
  const pool = await getPool();
  const result = await pool.request().query(`
    SELECT lr.*, e.Name AS EmployeeName
    FROM dbo.LeaveRequests lr
    JOIN dbo.Employees e ON e.EmployeeId = lr.EmployeeId
    WHERE lr.Status = 'Pending'
    ORDER BY lr.CreatedAt ASC
  `);
  res.render('manager', { user: req.session.user, requests: result.recordset });
});

app.post('/manager/leave-requests/:id/approve', requireLogin, requireManager, async (req, res) => {
  await reviewLeave(req.params.id, 'Approved', req.session.user.id);
  res.redirect('/manager/leave-requests');
});

app.post('/manager/leave-requests/:id/reject', requireLogin, requireManager, async (req, res) => {
  await reviewLeave(req.params.id, 'Rejected', req.session.user.id);
  res.redirect('/manager/leave-requests');
});

async function reviewLeave(leaveId, status, reviewerId) {
  const pool = await getPool();
  await pool
    .request()
    .input('leaveId', sql.Int, leaveId)
    .input('status', sql.NVarChar, status)
    .input('reviewerId', sql.Int, reviewerId)
    .query(`
      UPDATE dbo.LeaveRequests
      SET Status = @status, ReviewedBy = @reviewerId, ReviewedAt = SYSUTCDATETIME()
      WHERE LeaveId = @leaveId
    `);

  if (status === 'Approved') {
    // Deduct leave days from balance
    const req2 = pool.request().input('leaveId', sql.Int, leaveId);
    await req2.query(`
      UPDATE e
      SET e.LeaveBalance = e.LeaveBalance - DATEDIFF(DAY, lr.StartDate, lr.EndDate) - 1
      FROM dbo.Employees e
      JOIN dbo.LeaveRequests lr ON lr.EmployeeId = e.EmployeeId
      WHERE lr.LeaveId = @leaveId
    `);
  }
}

app.get('/', (req, res) => res.redirect(req.session.user ? '/dashboard' : '/login'));

// ---- Error handling ----
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send('Something went wrong');
});

app.listen(PORT, () => console.log(`Listening on port ${PORT}`));
