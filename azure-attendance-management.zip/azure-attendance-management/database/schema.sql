-- Azure SQL Database schema: Employee Attendance & Leave Management
-- Run via: sqlcmd -S <server>.database.windows.net -d <db> -U <admin> -P <pwd> -i schema.sql

IF OBJECT_ID('dbo.LeaveRequests', 'U') IS NOT NULL DROP TABLE dbo.LeaveRequests;
IF OBJECT_ID('dbo.Attendance', 'U') IS NOT NULL DROP TABLE dbo.Attendance;
IF OBJECT_ID('dbo.Employees', 'U') IS NOT NULL DROP TABLE dbo.Employees;
GO

CREATE TABLE dbo.Employees (
    EmployeeId      INT IDENTITY(1,1) PRIMARY KEY,
    Name            NVARCHAR(100)   NOT NULL,
    Email           NVARCHAR(256)   NOT NULL UNIQUE,
    PasswordHash    NVARCHAR(256)   NOT NULL,  -- bcrypt hash, never plaintext
    Department      NVARCHAR(100)   NULL,
    IsManager       BIT             NOT NULL DEFAULT 0,
    ManagerId       INT             NULL FOREIGN KEY REFERENCES dbo.Employees(EmployeeId),
    LeaveBalance    INT             NOT NULL DEFAULT 20,
    CreatedAt       DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

CREATE TABLE dbo.Attendance (
    AttendanceId    INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeId      INT             NOT NULL FOREIGN KEY REFERENCES dbo.Employees(EmployeeId),
    [Date]          DATE            NOT NULL,
    CheckIn         DATETIME2       NULL,
    CheckOut        DATETIME2       NULL,
    Status          NVARCHAR(20)    NOT NULL DEFAULT 'Present', -- Present/Absent/Half-Day
    CONSTRAINT UQ_Employee_Date UNIQUE (EmployeeId, [Date])
);
GO

CREATE TABLE dbo.LeaveRequests (
    LeaveId         INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeId      INT             NOT NULL FOREIGN KEY REFERENCES dbo.Employees(EmployeeId),
    LeaveType       NVARCHAR(50)    NOT NULL, -- Sick/Casual/Earned/Unpaid
    StartDate       DATE            NOT NULL,
    EndDate         DATE            NOT NULL,
    Reason          NVARCHAR(500)   NULL,
    Status          NVARCHAR(20)    NOT NULL DEFAULT 'Pending', -- Pending/Approved/Rejected
    ReviewedBy       INT            NULL FOREIGN KEY REFERENCES dbo.Employees(EmployeeId),
    ReviewedAt       DATETIME2      NULL,
    CreatedAt         DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    CHECK (EndDate >= StartDate)
);
GO

CREATE INDEX IX_Attendance_EmployeeId ON dbo.Attendance(EmployeeId);
CREATE INDEX IX_LeaveRequests_EmployeeId ON dbo.LeaveRequests(EmployeeId);
CREATE INDEX IX_LeaveRequests_Status ON dbo.LeaveRequests(Status);
GO

-- Seed data (password for both = "Passw0rd!" bcrypt-hashed)
INSERT INTO dbo.Employees (Name, Email, PasswordHash, Department, IsManager, LeaveBalance)
VALUES ('Priya Manager', 'priya.manager@example.com', '$2b$10$replace_with_real_bcrypt_hash', 'Engineering', 1, 20);
GO

INSERT INTO dbo.Employees (Name, Email, PasswordHash, Department, IsManager, ManagerId, LeaveBalance)
VALUES ('Arjun Employee', 'arjun.employee@example.com', '$2b$10$replace_with_real_bcrypt_hash', 'Engineering', 0, 1, 20);
GO
