output "resource_group_name" {
  value = azurerm_resource_group.this.name
}

output "app_service_name" {
  value = module.app_service.app_name
}

output "app_service_url" {
  value = "https://${module.app_service.default_hostname}"
}

output "sql_server_fqdn" {
  value = module.sql.server_fqdn
}

output "sql_database_name" {
  value = module.sql.database_name
}

output "key_vault_name" {
  value = module.keyvault.key_vault_name
}

output "app_insights_connection_string" {
  value     = module.monitoring.app_insights_connection_string
  sensitive = true
}
