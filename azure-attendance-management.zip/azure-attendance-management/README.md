# Azure Employee Attendance & Leave Management System

Employees check in/out and apply for leave; managers approve/reject. Built on
App Service (Linux, Node.js), Azure SQL Database, Key Vault (Managed Identity),
Application Insights + Log Analytics, provisioned with Terraform.

## Architecture

```
Internet -> App Service (Linux, Node/Express, System-Assigned Managed Identity)
                |                         |
                v                         v
          Azure SQL DB              Key Vault (sql-connection-string secret)
                                          ^
                                          | Get/List via access policy
                                    App Service Identity

App Insights + Log Analytics <- telemetry from App Service
Azure Monitor Action Group <- Http5xx > 5 / 5min alert
```

## Repo layout

```
terraform/     Infra as code (modules: app-service, sql, keyvault, monitoring)
application/   Node.js/Express app (EJS views, mssql driver)
database/      schema.sql (run once against the provisioned Azure SQL DB)
.github/workflows/deploy.yml   CI/CD via OIDC federated login
```

## Prerequisites

- Azure subscription + `az` CLI logged in (`az login`)
- Terraform >= 1.6
- Node.js 20+
- `sqlcmd` (or Azure Data Studio) for schema deployment

## 1. Provision infrastructure

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars   # fill in alert_email, allowed_client_ip
export TF_VAR_sql_admin_password='<a-strong-password>'   # never put this in tfvars

terraform init
terraform plan -out plan.tfplan
terraform apply plan.tfplan
```

Capture outputs:

```bash
terraform output app_service_url
terraform output sql_server_fqdn
terraform output key_vault_name
```

## 2. Load the database schema

```bash
sqlcmd -S $(terraform output -raw sql_server_fqdn) \
       -d $(terraform output -raw sql_database_name) \
       -U sqladminuser -P "$TF_VAR_sql_admin_password" \
       -i ../database/schema.sql
```

> Generate real bcrypt hashes before seeding users:
> `node -e "console.log(require('bcryptjs').hashSync('Passw0rd!', 10))"`
> and replace the placeholder hashes in `schema.sql`.

## 3. Deploy the application

Manual (first deploy / smoke test):

```bash
cd application
npm ci
zip -r ../release.zip . -x "*.git*"
az webapp deploy \
  --resource-group $(terraform -chdir=../terraform output -raw resource_group_name) \
  --name $(terraform -chdir=../terraform output -raw app_service_name) \
  --src-path ../release.zip --type zip
```

Ongoing: push to `main` and let `.github/workflows/deploy.yml` handle it (see
below for the GitHub secrets/OIDC setup).

## 4. CI/CD — GitHub Actions OIDC (no stored client secret)

```bash
az ad app create --display-name "gh-attendance-app" --query appId -o tsv
# -> APP_ID

az ad sp create --id <APP_ID>

az ad app federated-credential create --id <APP_ID> --parameters '{
  "name": "github-main",
  "issuer": "https://token.actions.githubusercontent.com",
  "subject": "repo:<org>/<repo>:ref:refs/heads/main",
  "audiences": ["api://AzureADTokenExchange"]
}'

az role assignment create --assignee <APP_ID> --role "Website Contributor" \
  --scope $(terraform -chdir=terraform output -raw resource_group_name | xargs -I{} az group show -n {} --query id -o tsv)
```

GitHub repo secrets to set:

| Secret | Value |
|---|---|
| `AZURE_CLIENT_ID` | `<APP_ID>` |
| `AZURE_TENANT_ID` | `az account show --query tenantId -o tsv` |
| `AZURE_SUBSCRIPTION_ID` | `az account show --query id -o tsv` |
| `AZURE_WEBAPP_NAME` | `terraform output -raw app_service_name` |

## Security notes (AZ-500 scope)

- SQL password is never committed — passed via `TF_VAR_sql_admin_password` / GitHub OIDC.
- Connection string lives only in Key Vault; App Service resolves it at runtime
  via its System-Assigned Managed Identity (`@Microsoft.KeyVault(...)` app setting).
- Key Vault access policy grants the app identity **Get/List only** — least privilege.
- `AllowAzureServices` firewall rule (`0.0.0.0`-`0.0.0.0`) is Azure's special
  "trusted platform" rule, not an open-to-internet rule — don't confuse the two on the exam.
- TLS 1.2 minimum enforced on both App Service and SQL Server; FTPS disabled; HTTPS-only.
- Next hardening step (not in this "Easy" build): Private Endpoint for SQL +
  VNet integration for App Service, removing public SQL access entirely.

## Testing checklist

| Scenario | How to verify |
|---|---|
| Employee login | Valid/invalid credentials via `/login` |
| Check-in / check-out | `/attendance/checkin`, `/attendance/checkout`, verify `MERGE` idempotency (double check-in doesn't duplicate) |
| Attendance history | `/attendance/history` renders rows across dates |
| Leave application | `/leave/apply` with overlapping/invalid dates |
| Manager approve/reject | `/manager/leave-requests`, confirm `LeaveBalance` decremented only on approval |
| Invalid login | Wrong password shows generic error, no user enumeration |
| DB connection failure | Stop SQL firewall temporarily, confirm `/healthz` still 200 but data routes return 500 gracefully |
| App restart | `az webapp restart`, confirm session invalidation behavior is acceptable |
| Alert firing | Force a few 5xx (e.g., break SQL_CONNECTION_STRING temporarily), confirm email from Action Group |

## Optional extensions

- Storage Account for leave attachments (medical certificates, etc.)
- Azure Front Door for WAF + global routing
- Private Endpoint for SQL Database, VNet-integrate App Service
