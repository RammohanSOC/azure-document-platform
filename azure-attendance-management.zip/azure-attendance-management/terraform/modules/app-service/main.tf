resource "azurerm_service_plan" "this" {
  name                = "asp-${var.name_prefix}-${var.suffix}"
  resource_group_name = var.resource_group_name
  location             = var.location
  os_type              = "Linux"
  sku_name             = var.sku_name
  tags                 = var.tags
}

resource "azurerm_linux_web_app" "this" {
  name                = "app-${var.name_prefix}-${var.suffix}"
  resource_group_name = var.resource_group_name
  location             = var.location
  service_plan_id      = azurerm_service_plan.this.id
  https_only            = true

  identity {
    type = "SystemAssigned"
  }

  site_config {
    minimum_tls_version = "1.2"
    ftps_state           = "Disabled"
    always_on            = var.sku_name != "F1" && var.sku_name != "D1"

    application_stack {
      node_version = "20-lts"
    }
  }

  app_settings = {
    "WEBSITE_RUN_FROM_PACKAGE"              = "1"
    "SCM_DO_BUILD_DURING_DEPLOYMENT"        = "true"
    "APPLICATIONINSIGHTS_CONNECTION_STRING" = var.app_insights_connection_string
    "APPINSIGHTS_INSTRUMENTATIONKEY"        = var.app_insights_instrumentation_key
    # Resolved by the App Service platform at runtime using the app's
    # Managed Identity - requires a Key Vault access policy (see keyvault module)
    "SQL_CONNECTION_STRING" = "@Microsoft.KeyVault(VaultName=${var.key_vault_name};SecretName=sql-connection-string)"
    "NODE_ENV"              = "production"
    "PORT"                  = "8080"
  }

  logs {
    detailed_error_messages = true
    failed_request_tracing  = true
    http_logs {
      file_system {
        retention_in_days = 7
        retention_in_mb   = 35
      }
    }
  }

  tags = var.tags
}

# AZ-500 note: key_vault_reference_identity_id defaults to the app's own
# SystemAssigned identity, which is what we want here.
