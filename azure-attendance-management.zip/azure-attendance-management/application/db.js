const sql = require('mssql');

// SQL_CONNECTION_STRING is injected by App Service as a Key Vault reference
// (@Microsoft.KeyVault(...)) — the platform resolves it to the real ADO
// connection string before the process ever sees it. Locally, set it in .env.
const connectionString = process.env.SQL_CONNECTION_STRING;

if (!connectionString) {
  console.error('SQL_CONNECTION_STRING is not set. Check App Service configuration / Key Vault access policy.');
}

let poolPromise;

function getPool() {
  if (!poolPromise) {
    poolPromise = new sql.ConnectionPool(connectionString)
      .connect()
      .then((pool) => {
        console.log('Connected to Azure SQL');
        return pool;
      })
      .catch((err) => {
        console.error('Database connection failed:', err.message);
        poolPromise = null; // allow retry on next request
        throw err;
      });
  }
  return poolPromise;
}

module.exports = { sql, getPool };
