resource "azurerm_mssql_server" "this" {
  name                         = "sql-${var.name_prefix}-${var.suffix}"
  resource_group_name         = var.resource_group_name
  location                     = var.location
  version                      = "12.0"
  administrator_login          = var.admin_username
  administrator_login_password = var.admin_password
  minimum_tls_version           = "1.2"
  public_network_access_enabled = true # tighten with Private Endpoint later (AZ-500/AZ-700 scope)

  tags = var.tags
}

resource "azurerm_mssql_database" "this" {
  name        = "sqldb-${var.name_prefix}"
  server_id   = azurerm_mssql_server.this.id
  sku_name    = var.database_sku
  max_size_gb = 2
  zone_redundant = false

  short_term_retention_policy {
    retention_days = 7
  }

  tags = var.tags
}

# Allow Azure services (App Service) to reach the logical server.
# Exam nuance (AZ-500/AZ-104): 0.0.0.0-0.0.0.0 is the special "Allow Azure
# services" rule, distinct from opening the DB to the whole internet.
resource "azurerm_mssql_firewall_rule" "allow_azure_services" {
  name             = "AllowAzureServices"
  server_id        = azurerm_mssql_server.this.id
  start_ip_address = "0.0.0.0"
  end_ip_address   = "0.0.0.0"
}

resource "azurerm_mssql_firewall_rule" "allow_client_ip" {
  count            = var.allowed_client_ip != "" ? 1 : 0
  name             = "AllowClientIP"
  server_id        = azurerm_mssql_server.this.id
  start_ip_address = var.allowed_client_ip
  end_ip_address   = var.allowed_client_ip
}
