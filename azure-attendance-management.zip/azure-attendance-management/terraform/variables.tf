variable "project_name" {
  description = "Short project prefix used in resource naming"
  type        = string
  default     = "attendance"
}

variable "environment" {
  description = "Environment name (dev/test/prod)"
  type        = string
  default     = "dev"
}

variable "location" {
  description = "Azure region"
  type        = string
  default     = "centralindia"
}

variable "app_service_sku" {
  description = "App Service Plan SKU"
  type        = string
  default     = "B1"
}

variable "sql_admin_username" {
  description = "SQL Server admin login"
  type        = string
  default     = "sqladminuser"
}

variable "sql_admin_password" {
  description = "SQL Server admin password (pass via TF_VAR_sql_admin_password, never commit)"
  type        = string
  sensitive   = true
}

variable "sql_database_sku" {
  description = "Azure SQL DB SKU (e.g. Basic, S0, GP_S_Gen5_1)"
  type        = string
  default     = "Basic"
}

variable "allowed_client_ip" {
  description = "Your IP for SQL firewall rule during setup (CIDR not required, single IP)"
  type        = string
  default     = ""
}

variable "alert_email" {
  description = "Email address to receive the HTTP 5xx alert"
  type        = string
}

variable "tags" {
  description = "Common resource tags"
  type        = map(string)
  default = {
    project = "employee-attendance-leave"
    managed_by = "terraform"
  }
}
