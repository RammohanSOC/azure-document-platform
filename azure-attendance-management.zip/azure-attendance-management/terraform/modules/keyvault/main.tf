data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "this" {
  name                       = var.key_vault_name
  resource_group_name       = var.resource_group_name
  location                   = var.location
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "standard"
  purge_protection_enabled   = false # set true for prod (AZ-500 exam nuance: irreversible once enabled)
  soft_delete_retention_days = 7

  # Deployer/Terraform identity gets full secret management rights
  access_policy {
    tenant_id = data.azurerm_client_config.current.tenant_id
    object_id = data.azurerm_client_config.current.object_id

    secret_permissions = ["Get", "List", "Set", "Delete", "Purge", "Recover"]
  }

  # App Service Managed Identity gets read-only rights (least privilege)
  access_policy {
    tenant_id = data.azurerm_client_config.current.tenant_id
    object_id = var.app_service_principal_id

    secret_permissions = ["Get", "List"]
  }

  tags = var.tags
}

resource "azurerm_key_vault_secret" "sql_connection_string" {
  name         = "sql-connection-string"
  value        = var.sql_connection_string
  key_vault_id = azurerm_key_vault.this.id
}
