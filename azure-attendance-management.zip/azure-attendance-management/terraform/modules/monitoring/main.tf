resource "azurerm_log_analytics_workspace" "this" {
  name                = "log-${var.name_prefix}-${var.suffix}"
  resource_group_name = var.resource_group_name
  location             = var.location
  sku                  = "PerGB2018"
  retention_in_days    = 30
  tags                 = var.tags
}

resource "azurerm_application_insights" "this" {
  name                = "appi-${var.name_prefix}-${var.suffix}"
  resource_group_name = var.resource_group_name
  location             = var.location
  workspace_id          = azurerm_log_analytics_workspace.this.id
  application_type      = "Node.JS"
  tags                   = var.tags
}

resource "azurerm_monitor_action_group" "this" {
  name                = "ag-${var.name_prefix}-${var.suffix}"
  resource_group_name = var.resource_group_name
  short_name           = "attendalert"

  email_receiver {
    name          = "primary-oncall"
    email_address = var.alert_email
  }

  tags = var.tags
}
