variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "name_prefix" { type = string }
variable "suffix" { type = string }
variable "sku_name" {
  type    = string
  default = "B1"
}
variable "app_insights_connection_string" { type = string }
variable "app_insights_instrumentation_key" { type = string }
variable "key_vault_name" {
  description = "Key Vault name used to build @Microsoft.KeyVault() references in app settings"
  type        = string
}
variable "tags" {
  type    = map(string)
  default = {}
}
